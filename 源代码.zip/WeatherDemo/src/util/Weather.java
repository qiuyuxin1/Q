package util;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

/**
 * 描述:天气工具类
 * 
 * @author cp
 * @date 2013-12-19
 * */
public class Weather {

	/**
	 * 描述:根据名称来获取天气信息
	 * 
	 * @param name
	 *            城市名或者编号
	 * @return 天气信息
	 */
	public Map<String, Object> report(String name) {
		String placeId = MapUtil.getPlaceIdByName(name);
		Map<String, Object> map = new HashMap<String, Object>();
		String url = "http://m.weather.com.cn/data/" + placeId + ".html";
		String content = UrlUtil.getURLContent(url);
		setData(content, map);
		return map;
	}

	/**
	 * 描述:解析并设置天气数据
	 * 
	 * @param datas
	 *            json数据
	 * @param map
	 *            存储Map
	 */
	private void setData(String datas, Map<String, Object> map) {
		if (!datas.startsWith("{")) {
			System.out.println("数据获取失败");
			return;
		}
		JSONObject data = JSONObject.fromObject(datas);
		JSONObject info = data.getJSONObject("weatherinfo");
		for (int i = 1; i <= 6; i++) {
			Map<String, String> oneDay = new HashMap<String, String>();
			oneDay.put("weather", info.getString("weather" + i));// 天气
			oneDay.put("temp", info.getString("temp" + i));// 气温
			oneDay.put("wind", info.getString("wind" + i));// 风况
			oneDay.put("fl", info.getString("fl" + i));// 风速
			map.put("day" + i, oneDay);
		}
		map.put("city", info.getString("city"));// 城市
		map.put("week", info.getString("week"));// 日期
		map.put("date_y", info.getString("date_y"));// 星期
		map.put("fchh", info.getString("fchh"));// 发布时间
		map.put("index", info.getString("index"));// 今天的穿衣指数
		map.put("index_uv", info.getString("index_uv"));// 紫外指数
		map.put("index_tr", info.getString("index_tr"));// 旅游指数
		map.put("index_co", info.getString("index_co"));// 舒适指数
		map.put("index_cl", info.getString("index_cl"));// 晨练指数
		map.put("index_xc", info.getString("index_xc"));// 洗车指数
		map.put("index_d", info.getString("index_d"));// 天气详细穿衣指数
	}
}