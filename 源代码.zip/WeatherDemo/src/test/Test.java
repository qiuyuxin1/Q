package test;

import java.util.Map;

import util.Weather;

public class Test {

	public static void main(String[] args) {
		Weather util = new Weather();
		Map<String, Object> map = util.report("池州");
		System.out.println(map.get("city"));
		System.out.println(map.get("week"));
		System.out.println(map.get("date_y"));
		for (int i = 1; i <= 6; i++) {
			System.out.println("第" + i + "天" + map.get("day" + i));
		}
	}
}
